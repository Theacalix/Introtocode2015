import random 
number =random.randint(1, 50)
print number 

user_guess = int(raw_input('Guess a number between 1 and 50. ')) 
attempts = 0 

while user_guess != number: 
	if user_guess > number: 
		print 'Try again! The number I am thinking of is lower than {}'.format(user_guess)
		user_guess = raw_input('Guess again.\n')
		attempts = + 1 
	elif user_guess < number: 
		print 'Try again! The number I am thinking of is higher than {}'.format(user_guess) 
		user_guess = raw_input('Guess again.\n')
		attepts = + 1
else:
	user_guess = number
	print 'Congradulations! The number was {}'.format(number)



