name = raw_input("What is your name? ") 
print 'Welcome back to SMA {}'.format(name.capitalize())