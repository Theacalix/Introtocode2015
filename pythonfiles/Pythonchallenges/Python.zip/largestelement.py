num_list = [3, 7, 2, 10, 14, 5]

def largest_element(num_list):
	largest_num = [] 
	for x in input_list:
		largest_num = 0 
		if x > largest_num:
			x = largest_num 

	return largest_num 


